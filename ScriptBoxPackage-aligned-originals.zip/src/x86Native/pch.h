﻿#pragma once

// DirectX headers.
#include <d3d11.h>
#include <d3dcompiler.h>
#include <d2d1_3.h>
#include <Windows.Graphics.DirectX.Direct3D11.interop.h>

// Win2D headers.
#include <Microsoft.Graphics.Canvas.native.h>
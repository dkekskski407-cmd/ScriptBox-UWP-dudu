﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace x86DisasmUWP
{
    public static class Helpers
    {
        public static EventHandler ErrorLog;
        public static EventHandler DebugLog;
        public static EventHandler NormalLog;
    }
}

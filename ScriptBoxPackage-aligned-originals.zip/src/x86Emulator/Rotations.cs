﻿namespace x86Emulator
{
    public enum Rotations
    {
        CCW0 = 0,
		CCW90 = 1,
		CCW180 = 2,
		CCW270 = 3,
	};
}
